<?php $__env->startSection('head'); ?>
<style>
.picture{
    float:left;
    padding-right: 25px;
}
.card-header{
    font-weight: bold;
    color:#F1C40F ;
    background-color:#048B9A ;
    padding: 25px;
}
.btn-default{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;
    float: right;
}
</style>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Mon profil</div>

                <div class="card-body">
                    <div class="picture"><div class="card"><div class="card-body">+</div></div></div>
                    <div class="surname">
                        <?php echo e(Auth::user()->name); ?>


                    </div>
                    <div class="email">
                        <?php echo e(Auth::user()->email); ?>

                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">Mes compétences</div>

                <div class="card-body">
                    <ul>
                        <li>
                            Bootstrap
                        </li>
                        <li>
                            Java
                        </li>
                    </ul>
                </div>
            </div>
            <div class="card">
                <div class="card-header">Quelques informations à propos de moi</div>

                <div class="card-body">
                    
                    BIO

                    <a class="btn btn-default" href="<?php echo e(url('/vous')); ?>">Ajouter une description</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>