<?php $__env->startSection('head'); ?>
<style>
.validate{
    align-items: right;
}
.btn-default{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;
}
.card-header{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;

}
.card{
    display:inline-block;
    margin-right: 10px;
}
</style>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        
            <div class="card" style="width:175px">
                <img class="card-img-top" src="avatar.jpg" alt="Ta tronche">
                <div class="card-body">
                    <h4 class="card-title">John Doe</h4>
                    <p class="card-text">Métier</p>
                    <a href="#" class="btn btn-info">Voir Profil</a>
                </div>
            </div>
            <div class="card" style="width:175px">
                <img class="card-img-top" src="avatar.jpg" alt="Ta tronche">
                <div class="card-body">
                    <h4 class="card-title">John Doe</h4>
                    <p class="card-text">Métier</p>
                    <a href="#" class="btn btn-info">Voir Profil</a>
                </div>
            </div>
            <div class="card" style="width:175px">
                <img class="card-img-top" src="avatar.jpg" alt="Ta tronche">
                <div class="card-body">
                    <h4 class="card-title">John Doe</h4>
                    <p class="card-text">Métier</p>
                    <a href="#" class="btn btn-info">Voir Profil</a>
                </div>
            </div>
        
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>