<?php $__env->startSection('head'); ?>
<style>
.validate{
    align-items: right;
}
.btn-default{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;
}
.card-header{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;

}
</style>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header" align="center">Bienvenue</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <p>Vous êtes connectés!</p>

                    <div class="row justify-content-center">

                    <a class="btn btn-default" href="<?php echo e(url('/vous')); ?>">Continuer</a></div>
                </div>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>