@extends('layouts.app')

@section('head')
<style>
.validate{
    align-items: right;
}
.btn-default{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;
}
.card-header{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;

}
</style>
@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header" align="center">1ere offre</div>

                <div class="card-body">
                    
                        Blablabla
                    <div class="row justify-content-center">

                    <a class="btn btn-default" href="{{ url('/vous') }}">Postuler</a></div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" align="center">2eme offre</div>

                <div class="card-body">
                    
                        Blablabla
                    <div class="row justify-content-center">

                    <a class="btn btn-default" href="{{ url('/vous') }}">Postuler</a></div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" align="center">3eme offre</div>

                <div class="card-body">
                    
                        <span style="font-weight:bold">Nom entreprise</span>
                        <ul>
                            <li>Poste disponible :</li>
                            <li>Description :</li>
                        </ul>
                     <div class="row justify-content-center">
                        <a class="btn btn-default" href="{{ url('/vous') }}">Postuler</a>
                    </div>
            </div>
                   
            </div>

        </div>
    </div>

</div>

@endsection
