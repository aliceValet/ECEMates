<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/vous', function () {
    return view('vous');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/notifications', function () {
    return view('notifications');
});
Route::get('/emploi', function () {
    return view('emploi');
});
Route::get('/network', function () {
    return view('network');
});
Route::get('/messenger', function () {
    return view('messenger');
});
Route::get('/accueil', function () {
    return view('accueil');
});
Route::get('email', 'EmailController@getForm');
Route::post('email', ['uses' => 'EmailController@postForm', 'as' => 'storeEmail']);
Route::resource('user', 'UserController');




