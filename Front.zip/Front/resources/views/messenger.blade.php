@extends('layouts.app')

@section('head')
<style>
.validate{
    align-items: right;
}
.btn-default{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;
}
input.form-control{
    width:250px;
}
td{
    width:100px;
}
.card{
    display:inline-block;
    margin-right: 10px;
}
.card-header{
    color:#F1C40F ;
    font-weight: bold;
}
input[type="text"] {
    width:700px;
    margin-left: 10px;
}
.btn-warning{
    margin-left: 10px;
}

</style>

<script type="text/javascript">
function Afficher(card){
document.getElementById(card).style.display = 'block';
}
</script>
@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-3">
        <form>
            <input class="form-control mr-sm-2" type="search" placeholder="Rechercher une conversation" aria-label="Search">
            <button class="btn btn-outline-info" type="submit"><img src="loop.png" alt="Search" height="25" width="25"/></button>
        </form>
        <div style="overflow-y:auto;">

  <table class="table table-hover">
    <tr>
      <th>Conversations récentes</th>
    </tr>
    <tr >
      <td onclick="Afficher('card')">Jill</td>
    </tr>
    <tr>
      <td>Eve</td>
    </tr>
    <tr>
      <td>Adam</td>
    </tr>
  </table>
</div>



</div>
<div class="col-md-9">
<div class="card" id="card" style="display:none">
    <div class="card-header" align="center">Votre conversation avec Jill</div>

                <div class="card-body">
                    
                        Blablabla
                    
                </div>
                <div class="footer">
                    <form>
                        <div class="input-group mb-3">
            <input type="text" placeholder="Tapez votre message" aria-label="Search"></div>
            <button class="btn btn-warning" type="submit"><img src="send.png" alt="Send" height="25" width="25"/></button>
        </form>
                </div>
</div>
</div>
</div>
    </div>
</div>

@endsection
