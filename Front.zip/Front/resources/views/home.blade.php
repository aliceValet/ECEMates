@extends('layouts.app')

@section('head')
<style>
.validate{
    align-items: right;
}
.btn-default{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;
}
.card-header{
    background-color: #048B9A;
    color: #F1C40F ;
    font-weight: bold;

}
</style>
@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header" align="center">Bienvenue</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <p>Vous êtes connectés!</p>

                    <div class="row justify-content-center">

                    <a class="btn btn-default" href="{{ url('/vous') }}">Continuer</a></div>
                </div>
            </div>

        </div>
    </div>

</div>

@endsection
