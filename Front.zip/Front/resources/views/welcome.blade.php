<!doctype html>
<html lang="{{ app()->getLocale() }}">
<link rel="icon" type="image/ico" href="favicon.ico" />

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>ECEMates</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
                background-color: #048B9A;
                color: #ffffff;
                padding-right: 321px;
                padding-left: 321px;
                padding-top: 35px;
                padding-bottom: 35px;

            }

            .title {
                font-size: 65px;
                font-weight: bold;
            }

            .links > a {
                color: #AAB7B8;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .picture{
                float : center;
            }
        </style>
    </head>
    <body>

        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                        <div class="col-md-4">
                <img src="ecemateslogo.png" alt="Logo ECEMates" height="100" width="100">
            </div>
                        
                    @else
                        <a href="{{ route('login') }}">Se connecter</a>
                        <a href="{{ route('register') }}">S'inscrire</a>
                        <div class="col-md-4">
                <img src="ecemateslogo.png" alt="Logo ECEMates" height="100" width="100">
            </div>
                    @endauth
                </div>
            @endif
              <div class="content">
                <div class="title m-b-md">
                    Bienvenue sur ECE Mates!
                </div>

                <div class="links">
                   ECE Mates est un réseau social professionnel rassemblant des élèves et anciens de l'ECE Paris.
                </div>

            </div>  
        </div>
            
        </div>
    </body>
</html>
