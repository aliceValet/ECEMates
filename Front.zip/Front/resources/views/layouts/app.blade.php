<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'ECE Mates') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <style>
    .navbar-custom{
        background-color: #048B9A;
    }

</style>
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-custom">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name', 'ECE Mates') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        @guest
                        @else
                             <li>
                                <form class="form-inline">
                                    <input class="form-control mr-sm-2" type="search" placeholder="Rechercher" aria-label="Search">
                                    <button class="btn btn-outline-info" type="submit"><img src="loop.png" alt="Search" height="25" width="25"/></button>
                                </form>
                                
                            </li>
                            
        
                        @endguest

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            <li><a class="nav-link" href="{{ route('login') }}">Se connecter</a></li>
                            <li><a class="nav-link" href="{{ route('register') }}">S'inscrire</a></li>
                        @else
                        <li>
                                <a class="nav-link" href="{{ url('/accueil') }}"><img src="home.png" alt="Accueil" height="45" width="45"/></a>
                            </li>
                            <li>
                                <a class="nav-link" href="{{ url('/vous') }}"><img src="me.png" alt="Mon profil" height="42" width="42"/></a>
                            </li>
                            <li>
                                <div class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" href="#collapse1"><img src="clochenotif.png" alt="Notifications" height="50" width="50"/></a>
                                            </h4>
                                        </div>
                                        <div id="collapse1" class="panel-collapse collapse">
                                            <ul class="list-group">
                                                <li class="list-group-item">Notif1</li>
                                                <li class="list-group-item">Notif2</li>
                                                <li class="list-group-item">Notif3</li>
                                            </ul>
                                            <div class="panel-footer">
                                                <a class="nav-link" href="{{ url('/notifications') }}">Notifications antérieures</a>
                                            </div>
                                        </div>
                                    </div>
                            </li>
                            <li>
                                <a class="nav-link" href="{{ url('/messenger') }}"><img src="messaging.png" alt="Messagerie" height="52" width="52"/></a>
                            </li>
                            <li>
                                <a class="nav-link" href="{{ url('/network') }}"><img src="network.png" alt="Mon Réseau" height="50" width="50"/></a>
                            </li>
                            <li>
                                <a class="nav-link" href="{{ url('/emploi') }}"><img src="jobs.png" alt="Emplois" height="42" width="42"/></a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                            
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
</body>
</html>
